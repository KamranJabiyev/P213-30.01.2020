﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using FirstMigration.DAL;
using FirstMigration.ViewModels;
using Microsoft.AspNetCore.Mvc;

namespace FirstMigration.Controllers
{
    public class HomeController : Controller
    {
        private readonly AppDbContext _db;
        public HomeController(AppDbContext db)
        {
            _db = db;
        }
        public IActionResult Index()
        {
            StudentDrugVM vm = new StudentDrugVM
            {
                Students=_db.Students,
                Drugs=_db.Drugs
            };
            return View(vm);
        }
    }
}