﻿using FirstMigration.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FirstMigration.ViewModels
{
    public class StudentDrugVM
    {
        public IEnumerable<Student> Students { get; set; }
        public IEnumerable<Drug> Drugs { get; set; }
    }
}
